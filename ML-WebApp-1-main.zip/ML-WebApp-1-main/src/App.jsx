
import { useEffect, useState } from "react";
import {
  Activity,
  BrainCircuit,
  ChartNoAxesCombined,
  CircleAlert,
  FlaskConical,
  GitBranch,
  LoaderCircle,
  RefreshCw,
  Target,
  Trees,
  Zap,
} from "lucide-react";

const API = "http://127.0.0.1:8000";

const initialValues = {
  sepalLength: 5.1,
  sepalWidth: 3.5,
  petalLength: 1.4,
  petalWidth: 0.2,
};

const inputFields = [
  { key: "sepalLength", label: "Sepal length", unit: "cm", min: 0.1, max: 10, step: 0.1 },
  { key: "sepalWidth", label: "Sepal width", unit: "cm", min: 0.1, max: 10, step: 0.1 },
  { key: "petalLength", label: "Petal length", unit: "cm", min: 0.1, max: 10, step: 0.1 },
  { key: "petalWidth", label: "Petal width", unit: "cm", min: 0.1, max: 10, step: 0.1 },
];

const number = (value, digits = 1) =>
  Number(value).toFixed(digits);

function MetricCard({ label, value, detail, icon: Icon }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-slate-900/80 p-5">
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-400">{label}</p>
        <Icon size={19} className="text-cyan-300" />
      </div>
      <p className="mt-4 text-3xl font-semibold tracking-tight text-white">
        {value}
      </p>
      <p className="mt-2 text-xs text-slate-500">{detail}</p>
    </div>
  );
}

function ProgressRow({ label, value, suffix = "%" }) {
  const width = Math.max(
    0,
    Math.min(100, suffix === "%" ? Number(value) : Number(value) * 100)
  );

  return (
    <div className="space-y-2">
      <div className="flex justify-between gap-4 text-sm">
        <span className="text-slate-300">{label}</span>
        <span className="font-mono text-white">
          {suffix === "%" ? `${number(value, 1)}%` : number(value, 3)}
        </span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-slate-800">
        <div
          className="h-full rounded-full bg-cyan-400 transition-all"
          style={{ width: `${width}%` }}
        />
      </div>
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("analytics");
  const [values, setValues] = useState(initialValues);
  const [prediction, setPrediction] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [treeCount, setTreeCount] = useState(100);
  const [criterion, setCriterion] = useState("gini");
  const [loading, setLoading] = useState(false);
  const [training, setTraining] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");

  async function loadAnalytics() {
    setLoading(true);
    setError("");

    try {
      const response = await fetch(`${API}/analytics`);
      if (!response.ok) throw new Error("Could not load model analytics.");
      const data = await response.json();
      setAnalytics(data);
      setTreeCount(data.n_estimators);
      setCriterion(data.criterion);
    } catch {
      setError(
        "Cannot connect to the backend. Start FastAPI at http://127.0.0.1:8000 and try again."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAnalytics();
  }, []);

  async function runPrediction(event) {
    event.preventDefault();
    setLoading(true);
    setError("");
    setNotice("");
    setPrediction(null);

    try {
      const response = await fetch(`${API}/predict`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || "Prediction failed.");
      }

      setPrediction(data);
    } catch (err) {
      setError(err.message || "Unable to get a prediction.");
    } finally {
      setLoading(false);
    }
  }

  async function retrainModel(event) {
    event.preventDefault();
    setTraining(true);
    setError("");
    setNotice("");

    try {
      const response = await fetch(`${API}/train`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          n_estimators: Number(treeCount),
          criterion,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || "Model training failed.");
      }

      setAnalytics(data.analytics);
      setNotice(
        `Model retrained with ${data.n_estimators} trees using ${data.criterion}.`
      );
      setTab("analytics");
      setPrediction(null);
    } catch (err) {
      setError(err.message || "Could not retrain the model.");
    } finally {
      setTraining(false);
    }
  }

  const metrics = analytics?.metrics;
  const tree = analytics?.tree_analysis;
  const matrix = analytics?.confusion_matrix || [];
  const classes = analytics?.dataset?.classes || [];

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100">
      <div className="mx-auto flex min-h-screen max-w-[1500px]">
        <aside className="hidden w-64 shrink-0 border-r border-white/10 bg-slate-950/70 p-6 lg:flex lg:flex-col">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-cyan-400/10 p-2.5 text-cyan-300">
              <BrainCircuit size={25} />
            </div>
            <div>
              <h1 className="font-semibold tracking-wide">NeuralLab</h1>
              <p className="text-xs text-slate-500">ML experimentation</p>
            </div>
          </div>

          <p className="mb-3 mt-12 text-[11px] font-semibold uppercase tracking-[0.2em] text-slate-600">
            Workspace
          </p>

          <button
            onClick={() => setTab("analytics")}
            className={`mb-2 flex items-center gap-3 rounded-xl px-4 py-3 text-sm transition ${
              tab === "analytics"
                ? "bg-cyan-400/10 text-cyan-200"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
          >
            <ChartNoAxesCombined size={18} /> Model analytics
          </button>
          <button
            onClick={() => setTab("prediction")}
            className={`flex items-center gap-3 rounded-xl px-4 py-3 text-sm transition ${
              tab === "prediction"
                ? "bg-cyan-400/10 text-cyan-200"
                : "text-slate-400 hover:bg-white/5 hover:text-white"
            }`}
          >
            <FlaskConical size={18} /> Make prediction
          </button>

          <div className="mt-auto rounded-2xl border border-white/10 bg-white/[0.03] p-4">
            <div className="flex items-center gap-2 text-sm text-emerald-300">
              <Activity size={16} /> API integration
            </div>
            <p className="mt-2 text-xs leading-5 text-slate-500">
              FastAPI + scikit-learn
            </p>
            <p className="mt-3 text-[11px] text-slate-600">
              Iris classification project
            </p>
          </div>
        </aside>

        <main className="min-w-0 flex-1 p-5 sm:p-8 xl:p-10">
          <header className="mb-8 flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-cyan-300">
                Machine learning studio
              </p>
              <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">
                Model workspace
              </h2>
              <p className="mt-2 text-sm text-slate-400">
                Explore model performance, tree splits, and predictions.
              </p>
            </div>

            <button
              onClick={loadAnalytics}
              disabled={loading}
              className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-slate-200 hover:bg-white/10 disabled:opacity-50"
            >
              <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
              Refresh metrics
            </button>
          </header>

          <div className="mb-6 flex gap-2 lg:hidden">
            <button
              onClick={() => setTab("analytics")}
              className="rounded-lg bg-slate-800 px-4 py-2 text-sm"
            >
              Analytics
            </button>
            <button
              onClick={() => setTab("prediction")}
              className="rounded-lg bg-slate-800 px-4 py-2 text-sm"
            >
              Prediction
            </button>
          </div>

          {error && (
            <div className="mb-6 flex gap-3 rounded-xl border border-rose-400/20 bg-rose-400/10 p-4 text-sm text-rose-200">
              <CircleAlert size={19} className="shrink-0" />
              {error}
            </div>
          )}

          {notice && (
            <div className="mb-6 rounded-xl border border-emerald-400/20 bg-emerald-400/10 p-4 text-sm text-emerald-200">
              {notice}
            </div>
          )}

          {tab === "analytics" && (
            <div className="space-y-6">
              <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                <MetricCard
                  label="Test accuracy"
                  value={metrics ? `${number(metrics.accuracy * 100)}%` : "—"}
                  detail="Correct predictions on held-out test data"
                  icon={Target}
                />
                <MetricCard
                  label="Macro precision"
                  value={metrics ? number(metrics.precision_macro * 100) + "%" : "—"}
                  detail="Precision averaged across species"
                  icon={Zap}
                />
                <MetricCard
                  label="Macro recall"
                  value={metrics ? number(metrics.recall_macro * 100) + "%" : "—"}
                  detail="Recall averaged across species"
                  icon={Activity}
                />
                <MetricCard
                  label="Macro F1-score"
                  value={metrics ? number(metrics.f1_macro * 100) + "%" : "—"}
                  detail="Balance of precision and recall"
                  icon={ChartNoAxesCombined}
                />
              </section>

              <section className="grid gap-6 xl:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-5 sm:p-6">
                  <div className="mb-6 flex items-center justify-between gap-4">
                    <div>
                      <h3 className="font-semibold">Feature importance</h3>
                      <p className="mt-1 text-xs text-slate-500">
                        Relative impurity-based importance
                      </p>
                    </div>
                    <ChartNoAxesCombined className="text-cyan-300" size={20} />
                  </div>

                  <div className="space-y-5">
                    {analytics?.feature_importance?.map((item) => (
                      <ProgressRow
                        key={item.feature}
                        label={item.feature}
                        value={item.importance}
                        suffix="score"
                      />
                    ))}
                    {!analytics && (
                      <p className="text-sm text-slate-500">
                        {loading ? "Loading analytics…" : "No metrics loaded yet."}
                      </p>
                    )}
                  </div>
                  <p className="mt-5 text-xs leading-5 text-slate-500">
                    These scores sum to approximately 1. They indicate how the
                    forest uses features for splitting; they do not prove causation.
                  </p>
                </div>

                <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-5 sm:p-6">
                  <div className="mb-5 flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">Confusion matrix</h3>
                      <p className="mt-1 text-xs text-slate-500">
                        Actual class by predicted class
                      </p>
                    </div>
                    <Target className="text-cyan-300" size={20} />
                  </div>

                  {matrix.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full border-separate border-spacing-1 text-center text-sm">
                        <thead>
                          <tr>
                            <th className="p-2 text-xs font-normal text-slate-500">
                              Actual ↓
                            </th>
                            {classes.map((name) => (
                              <th key={name} className="p-2 text-xs font-medium text-slate-300">
                                {name}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {matrix.map((row, i) => (
                            <tr key={classes[i]}>
                              <th className="px-2 text-left text-xs font-medium text-slate-300">
                                {classes[i]}
                              </th>
                              {row.map((count, j) => (
                                <td
                                  key={j}
                                  className={`rounded-lg p-3 font-mono ${
                                    i === j
                                      ? "bg-emerald-400/20 text-emerald-200"
                                      : count > 0
                                      ? "bg-rose-400/10 text-rose-200"
                                      : "bg-slate-800 text-slate-400"
                                  }`}
                                >
                                  {count}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-sm text-slate-500">
                      {loading ? "Loading confusion matrix…" : "No matrix available."}
                    </p>
                  )}
                  <p className="mt-4 text-xs text-slate-500">
                    Diagonal cells are correct predictions; off-diagonal cells
                    are misclassifications.
                  </p>
                </div>
              </section>

              <section className="grid gap-6 xl:grid-cols-[0.8fr_1.2fr]">
                <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-5 sm:p-6">
                  <div className="mb-5 flex items-center gap-3">
                    <Trees className="text-cyan-300" size={21} />
                    <div>
                      <h3 className="font-semibold">Experiment controls</h3>
                      <p className="mt-1 text-xs text-slate-500">
                        Retrain the forest and recalculate test metrics
                      </p>
                    </div>
                  </div>

                  <form onSubmit={retrainModel} className="space-y-5">
                    <label className="block">
                      <span className="mb-2 block text-sm text-slate-300">
                        Number of trees: <strong>{treeCount}</strong>
                      </span>
                      <input
                        type="range"
                        min="10"
                        max="500"
                        step="10"
                        value={treeCount}
                        onChange={(e) => setTreeCount(Number(e.target.value))}
                        className="w-full accent-cyan-400"
                      />
                      <span className="mt-1 flex justify-between text-xs text-slate-600">
                        <span>10</span><span>500</span>
                      </span>
                    </label>

                    <label className="block">
                      <span className="mb-2 block text-sm text-slate-300">
                        Split criterion
                      </span>
                      <select
                        value={criterion}
                        onChange={(e) => setCriterion(e.target.value)}
                        className="w-full rounded-xl border border-white/10 bg-slate-950 px-3 py-3 text-sm text-white outline-none focus:border-cyan-400"
                      >
                        <option value="gini">Gini impurity</option>
                        <option value="entropy">Entropy / information gain</option>
                      </select>
                    </label>

                    <button
                      type="submit"
                      disabled={training}
                      className="flex w-full items-center justify-center gap-2 rounded-xl bg-cyan-400 px-4 py-3 text-sm font-semibold text-slate-950 transition hover:bg-cyan-300 disabled:opacity-50"
                    >
                      {training ? (
                        <><LoaderCircle size={17} className="animate-spin" /> Training model…</>
                      ) : (
                        <><RefreshCw size={17} /> Retrain and evaluate</>
                      )}
                    </button>
                  </form>

                  <div className="mt-5 grid grid-cols-2 gap-3">
                    <div className="rounded-xl bg-slate-950 p-3">
                      <p className="text-xs text-slate-500">Training samples</p>
                      <p className="mt-1 text-xl font-semibold">
                        {analytics?.dataset?.training_samples ?? "—"}
                      </p>
                    </div>
                    <div className="rounded-xl bg-slate-950 p-3">
                      <p className="text-xs text-slate-500">Test samples</p>
                      <p className="mt-1 text-xl font-semibold">
                        {analytics?.dataset?.test_samples ?? "—"}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="rounded-2xl border border-white/10 bg-slate-900/70 p-5 sm:p-6">
                  <div className="mb-5 flex items-center gap-3">
                    <GitBranch className="text-cyan-300" size={21} />
                    <div>
                      <h3 className="font-semibold">Decision tree analysis</h3>
                      <p className="mt-1 text-xs text-slate-500">
                        First tree in the forest, not the entire forest
                      </p>
                    </div>
                  </div>

                  <div className="mb-5 grid grid-cols-3 gap-3">
                    <div className="rounded-xl bg-slate-950 p-3">
                      <p className="text-xs text-slate-500">Depth</p>
                      <p className="mt-1 text-xl font-semibold">
                        {tree?.tree_depth ?? "—"}
                      </p>
                    </div>
                    <div className="rounded-xl bg-slate-950 p-3">
                      <p className="text-xs text-slate-500">Leaf nodes</p>
                      <p className="mt-1 text-xl font-semibold">
                        {tree?.leaf_count ?? "—"}
                      </p>
                    </div>
                    <div className="rounded-xl bg-slate-950 p-3">
                      <p className="text-xs text-slate-500">Splits</p>
                      <p className="mt-1 text-xl font-semibold">
                        {tree?.split_count ?? "—"}
                      </p>
                    </div>
                  </div>

                  <div className="max-h-[420px] space-y-3 overflow-auto pr-1">
                    {tree?.splits?.map((split) => (
                      <div
                        key={split.node}
                        className="rounded-xl border border-white/5 bg-slate-950/70 p-4"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="text-sm font-medium text-white">
                            Node {split.node}: {split.feature}
                          </span>
                          <span className="rounded-md bg-cyan-400/10 px-2 py-1 text-xs text-cyan-200">
                            threshold ≤ {split.threshold}
                          </span>
                        </div>
                        <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
                          <div>
                            <p className="text-xs text-slate-500">Gini</p>
                            <p className="mt-1 font-mono text-sm">{number(split.gini, 4)}</p>
                          </div>
                          <div>
                            <p className="text-xs text-slate-500">Entropy</p>
                            <p className="mt-1 font-mono text-sm">{number(split.entropy, 4)}</p>
                          </div>
                          <div>
                            <p className="text-xs text-slate-500">Information gain</p>
                            <p className="mt-1 font-mono text-sm text-emerald-300">
                              {number(split.information_gain, 4)}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-slate-500">Samples</p>
                            <p className="mt-1 font-mono text-sm">{split.samples}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                    {!tree && (
                      <p className="text-sm text-slate-500">
                        {loading ? "Loading tree details…" : "No tree data available."}
                      </p>
                    )}
                  </div>
                </div>
              </section>

              <section className="rounded-2xl border border-white/10 bg-slate-900/70 p-5 sm:p-6">
                <h3 className="font-semibold">Per-class performance</h3>
                <p className="mt-1 text-xs text-slate-500">
                  Scores calculated from held-out test examples
                </p>
                <div className="mt-5 grid gap-4 md:grid-cols-3">
                  {classes.map((name) => {
                    const item = analytics?.class_report?.[name];
                    return (
                      <div key={name} className="rounded-xl bg-slate-950 p-4">
                        <h4 className="mb-4 font-medium capitalize">{name}</h4>
                        <div className="space-y-3 text-sm">
                          <div className="flex justify-between">
                            <span className="text-slate-400">Precision</span>
                            <span>{item ? number(item.precision * 100) + "%" : "—"}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Recall</span>
                            <span>{item ? number(item.recall * 100) + "%" : "—"}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">F1-score</span>
                            <span>{item ? number(item.f1_score * 100) + "%" : "—"}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-400">Test examples</span>
                            <span>{item?.support ?? "—"}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>

              <p className="text-xs leading-5 text-slate-600">
                Evaluation uses a stratified 80/20 train/test split with a fixed
                random seed. Tree split metrics are calculated for the first
                estimator only. Information gain is entropy reduction, even when
                the forest is trained using the Gini criterion.
              </p>
            </div>
          )}

          {tab === "prediction" && (
            <div className="grid gap-6 xl:grid-cols-[1fr_0.8fr]">
              <section className="rounded-2xl border border-white/10 bg-slate-900/70 p-5 sm:p-7">
                <div className="mb-6 flex items-center gap-3">
                  <FlaskConical className="text-cyan-300" size={22} />
                  <div>
                    <h3 className="font-semibold">Iris measurements</h3>
                    <p className="mt-1 text-xs text-slate-500">
                      Enter the flower dimensions in centimeters
                    </p>
                  </div>
                </div>

                <form onSubmit={runPrediction} className="space-y-5">
                  {inputFields.map((field) => (
                    <label key={field.key} className="block">
                      <span className="mb-2 flex justify-between text-sm">
                        <span className="text-slate-300">{field.label}</span>
                        <span className="text-slate-500">{field.unit}</span>
                      </span>
                      <input
                        type="number"
                        required
                        min={field.min}
                        max={field.max}
                        step={field.step}
                        value={values[field.key]}
                        onChange={(e) => {
                          setValues((previous) => ({
                            ...previous,
                            [field.key]: e.target.value,
                          }));
                          setPrediction(null);
                        }}
                        className="w-full rounded-xl border border-white/10 bg-slate-950 px-4 py-3 text-white outline-none focus:border-cyan-400"
                      />
                    </label>
                  ))}

                  <div className="flex flex-wrap gap-3 pt-2">
                    <button
                      type="submit"
                      disabled={loading}
                      className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-cyan-400 px-4 py-3 font-semibold text-slate-950 hover:bg-cyan-300 disabled:opacity-50"
                    >
                      {loading ? (
                        <><LoaderCircle size={17} className="animate-spin" /> Predicting…</>
                      ) : (
                        <><Zap size={17} /> Run prediction</>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setValues(initialValues);
                        setPrediction(null);
                        setError("");
                      }}
                      className="rounded-xl border border-white/10 px-4 py-3 text-sm text-slate-300 hover:bg-white/5"
                    >
                      Reset
                    </button>
                  </div>
                </form>
              </section>

              <section className="rounded-2xl border border-white/10 bg-slate-900/70 p-5 sm:p-7">
                <div className="mb-6 flex items-center gap-3">
                  <BrainCircuit className="text-cyan-300" size={22} />
                  <div>
                    <h3 className="font-semibold">Prediction result</h3>
                    <p className="mt-1 text-xs text-slate-500">
                      Response from the live FastAPI model
                    </p>
                  </div>
                </div>

                {prediction ? (
                  <>
                    <p className="text-sm text-slate-400">Predicted species</p>
                    <h4 className="mt-2 text-3xl font-semibold capitalize text-cyan-200">
                      {prediction.prediction}
                    </h4>
                    <div className="mt-6 rounded-xl bg-slate-950 p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-slate-400">Model confidence</span>
                        <span className="text-xl font-semibold">
                          {number(prediction.confidence)}%
                        </span>
                      </div>
                      <div className="mt-3 h-2 rounded-full bg-slate-800">
                        <div
                          className="h-2 rounded-full bg-cyan-400"
                          style={{ width: `${prediction.confidence}%` }}
                        />
                      </div>
                    </div>
                    <h5 className="mb-4 mt-6 text-sm font-medium">
                      Class probabilities
                    </h5>
                    <div className="space-y-4">
                      {Object.entries(prediction.probabilities).map(([name, score]) => (
                        <ProgressRow
                          key={name}
                          label={name}
                          value={score}
                        />
                      ))}
                    </div>
                    <p className="mt-5 text-xs leading-5 text-slate-500">
                      Confidence is the highest predicted class probability;
                      it is not a guarantee that the prediction is correct.
                    </p>
                  </>
                ) : (
                  <div className="flex min-h-64 flex-col items-center justify-center text-center">
                    <div className="rounded-2xl bg-slate-950 p-4 text-slate-500">
                      <FlaskConical size={30} />
                    </div>
                    <p className="mt-4 font-medium text-slate-300">
                      Ready for a prediction
                    </p>
                    <p className="mt-2 max-w-xs text-sm leading-6 text-slate-500">
                      Enter the measurements and run the model to see its
                      predicted species and probability scores.
                    </p>
                  </div>
                )}
              </section>
            </div>
          )}

          <footer className="mt-10 flex flex-wrap items-center justify-between gap-3 border-t border-white/10 pt-5 text-xs text-slate-600">
            <span>NeuralLab · ML Experimentation Dashboard</span>
            <span>React · FastAPI · Scikit-learn</span>
          </footer>
        </main>
      </div>
    </div>
  );
}
