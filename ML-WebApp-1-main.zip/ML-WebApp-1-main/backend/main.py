
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
)
import numpy as np

app = FastAPI(title="NeuralLab ML API", version="2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dataset
iris = load_iris()
X = iris.data
y = iris.target
FEATURE_NAMES = list(iris.feature_names)
CLASS_NAMES = list(iris.target_names)

# Reproducible train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y,
)

# Model settings
tree_count = 100
split_criterion = "gini"

model = RandomForestClassifier(
    n_estimators=tree_count,
    criterion=split_criterion,
    random_state=42,
    n_jobs=-1,
)
model.fit(X_train, y_train)


class PredictionInput(BaseModel):
    sepalLength: float = Field(gt=0, le=20)
    sepalWidth: float = Field(gt=0, le=20)
    petalLength: float = Field(gt=0, le=20)
    petalWidth: float = Field(gt=0, le=20)


class TrainInput(BaseModel):
    n_estimators: int = Field(default=100, ge=10, le=500)
    criterion: str = "gini"


def entropy_from_counts(counts):
    """Calculate entropy in bits."""
    counts = np.asarray(counts, dtype=float)
    total = counts.sum()

    if total <= 0:
        return 0.0

    probabilities = counts / total
    probabilities = probabilities[probabilities > 0]

    return float(-np.sum(probabilities * np.log2(probabilities)))


def gini_from_counts(counts):
    """Calculate Gini impurity."""
    counts = np.asarray(counts, dtype=float)
    total = counts.sum()

    if total <= 0:
        return 0.0

    probabilities = counts / total
    return float(1.0 - np.sum(probabilities**2))


def get_tree_analytics(tree_model):
    """
    Inspect the first tree in the forest.

    Information gain is calculated as entropy(parent) minus
    the weighted entropy of the two children.
    """
    tree = tree_model.tree_
    nodes = []

    for node_id in range(tree.node_count):
        left = int(tree.children_left[node_id])
        right = int(tree.children_right[node_id])

        # Leaf nodes do not make a split.
        if left == right:
            continue

        # Works with both normalized and count-based tree.value formats.
        parent_counts = np.asarray(tree.value[node_id][0], dtype=float)
        left_counts = np.asarray(tree.value[left][0], dtype=float)
        right_counts = np.asarray(tree.value[right][0], dtype=float)

        parent_entropy = entropy_from_counts(parent_counts)
        parent_gini = gini_from_counts(parent_counts)

        left_entropy = entropy_from_counts(left_counts)
        right_entropy = entropy_from_counts(right_counts)

        parent_weight = float(tree.weighted_n_node_samples[node_id])
        left_weight = float(tree.weighted_n_node_samples[left])
        right_weight = float(tree.weighted_n_node_samples[right])

        if parent_weight > 0:
            weighted_child_entropy = (
                left_weight * left_entropy
                + right_weight * right_entropy
            ) / parent_weight
        else:
            weighted_child_entropy = 0.0

        information_gain = parent_entropy - weighted_child_entropy

        feature_index = int(tree.feature[node_id])

        nodes.append({
            "node": node_id,
            "feature": FEATURE_NAMES[feature_index],
            "threshold": round(float(tree.threshold[node_id]), 4),
            "samples": int(tree.n_node_samples[node_id]),
            "gini": round(parent_gini, 5),
            "entropy": round(parent_entropy, 5),
            "information_gain": round(
                max(0.0, information_gain), 5
            ),
            "left_node": left,
            "right_node": right,
        })

    return {
        "tree_depth": int(tree.max_depth),
        "leaf_count": int(tree.n_leaves),
        "split_count": len(nodes),
        "splits": nodes,
    }


def build_analytics():
    predictions = model.predict(X_test)

    report = classification_report(
        y_test,
        predictions,
        labels=[0, 1, 2],
        target_names=CLASS_NAMES,
        output_dict=True,
        zero_division=0,
    )

    matrix = confusion_matrix(
        y_test, predictions, labels=[0, 1, 2]
    )

    feature_importance = [
        {
            "feature": FEATURE_NAMES[i],
            "importance": round(float(model.feature_importances_[i]), 5),
        }
        for i in range(len(FEATURE_NAMES))
    ]
    feature_importance.sort(
        key=lambda item: item["importance"], reverse=True
    )

    forest_depths = [tree.tree_.max_depth for tree in model.estimators_]
    forest_leaves = [tree.tree_.n_leaves for tree in model.estimators_]

    return {
        "model": "RandomForestClassifier",
        "criterion": split_criterion,
        "n_estimators": tree_count,
        "dataset": {
            "name": "Iris",
            "total_samples": int(len(X)),
            "training_samples": int(len(X_train)),
            "test_samples": int(len(X_test)),
            "features": FEATURE_NAMES,
            "classes": CLASS_NAMES,
        },
        "metrics": {
            "accuracy": round(float(accuracy_score(y_test, predictions)), 4),
            "precision_macro": round(
                float(precision_score(
                    y_test, predictions, average="macro", zero_division=0
                )), 4
            ),
            "recall_macro": round(
                float(recall_score(
                    y_test, predictions, average="macro", zero_division=0
                )), 4
            ),
            "f1_macro": round(
                float(f1_score(
                    y_test, predictions, average="macro", zero_division=0
                )), 4
            ),
        },
        "class_report": {
            name: {
                "precision": round(float(report[name]["precision"]), 4),
                "recall": round(float(report[name]["recall"]), 4),
                "f1_score": round(float(report[name]["f1-score"]), 4),
                "support": int(report[name]["support"]),
            }
            for name in CLASS_NAMES
        },
        "confusion_matrix": matrix.tolist(),
        "feature_importance": feature_importance,
        "forest_summary": {
            "average_depth": round(float(np.mean(forest_depths)), 2),
            "average_leaves": round(float(np.mean(forest_leaves)), 2),
        },
        "tree_analysis": get_tree_analytics(model.estimators_[0]),
    }


@app.get("/")
def home():
    return {
        "message": "NeuralLab ML API is running",
        "docs": "/docs",
    }


@app.get("/health")
def health():
    return {
        "status": "online",
        "model": "RandomForestClassifier",
        "criterion": split_criterion,
        "n_estimators": tree_count,
    }


@app.post("/predict")
def predict(data: PredictionInput):
    features = [[
        data.sepalLength,
        data.sepalWidth,
        data.petalLength,
        data.petalWidth,
    ]]

    prediction_index = int(model.predict(features)[0])
    probabilities = model.predict_proba(features)[0]

    return {
        "prediction": CLASS_NAMES[prediction_index],
        "confidence": round(float(max(probabilities)) * 100, 2),
        "probabilities": {
            CLASS_NAMES[i]: round(float(probabilities[i]) * 100, 2)
            for i in range(len(CLASS_NAMES))
        },
    }


@app.get("/analytics")
def analytics():
    return build_analytics()


@app.post("/train")
def train(data: TrainInput):
    global model, tree_count, split_criterion

    if data.criterion not in ("gini", "entropy"):
        raise HTTPException(
            status_code=400,
            detail="criterion must be 'gini' or 'entropy'",
        )

    tree_count = data.n_estimators
    split_criterion = data.criterion

    model = RandomForestClassifier(
        n_estimators=tree_count,
        criterion=split_criterion,
        random_state=42,
        n_jobs=-1,
    )
    model.fit(X_train, y_train)

    return {
        "message": "Model trained successfully",
        "n_estimators": tree_count,
        "criterion": split_criterion,
        "analytics": build_analytics(),
    }
